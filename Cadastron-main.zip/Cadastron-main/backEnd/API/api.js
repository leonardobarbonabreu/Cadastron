const express = require('express');
const mysql = require('mysql2');
const cors = require('cors'); // Importa o pacote cors
const app = express();
const port = 3000;

// Configurar a conexão com o banco de dados MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root', // Substitua pela sua senha de root
  password: '', // Adicione sua senha aqui
  database: 'cadastron_db'
});

// Conectar ao banco de dados
db.connect((err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err);
    return;
  }
  console.log('Conectado ao banco de dados MySQL');
});

// Middleware para permitir leitura de JSON no body das requisições
app.use(express.json());
app.use(cors()); // Adiciona o middleware cors

// Rota para listar todos os usuários
app.get('/usuarios', (req, res) => {
  const query = 'SELECT * FROM users';
  db.query(query, (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

// Rota para obter um usuário específico por ID
app.get('/usuarios/:id', (req, res) => {
  const { id } = req.params;
  const query = 'SELECT * FROM users WHERE id = ?';
  db.query(query, [id], (err, results) => {
    if (err) throw err;
    res.json(results[0]);
  });
});

// Rota para adicionar um novo usuário
app.post('/usuarios', (req, res) => {
  const { nome, email, senha, dataAniversario } = req.body;
  const query = 'INSERT INTO users (nome, email, senha, dataAniversario) VALUES (?, ?, ?, ?)';
  db.query(query, [nome, email, senha, dataAniversario], (err, result) => {
    if (err) throw err;
    res.json({ id: result.insertId, nome, email });
  });
});

// Rota para deletar um usuário por ID
app.delete('/usuarios/:id', (req, res) => {
  const { id } = req.params;
  const query = 'DELETE FROM users WHERE id = ?';
  db.query(query, [id], (err, result) => {
    if (err) throw err;
    res.status(204).send(); // No content
  });
});

// Iniciar o servidor
app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});
