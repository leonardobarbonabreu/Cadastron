// Variável global para armazenar o ID do usuário em edição
let usuarioEmEdicaoId = null;

// Função para gravar (adicionar) um novo usuário
async function gravar() {
    const nome = document.getElementById('edtNome').value;
    const email = document.getElementById('edtEmail').value;
    const senha = document.getElementById('edtSenha').value;
    const dataAniversario = document.getElementById('edtBirth').value;

    try {
        const response = await fetch('http://localhost:3000/usuarios', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ nome, email, senha, dataAniversario }),
        });

        if (!response.ok) {
            throw new Error('Erro ao adicionar usuário');
        }

        const novoUsuario = await response.json();
        console.log('Usuário adicionado:', novoUsuario);

        // Limpar os campos do formulário
        limparFormulario();

        // Atualizar a lista de usuários após adicionar
        listarUsuarios();
    } catch (error) {
        console.error('Erro ao adicionar usuário:', error);
        alert('Erro ao adicionar usuário. Por favor, tente novamente.');
    }
}

// Função para listar todos os usuários
async function listarUsuarios() {
    try {
        const lista = document.getElementById('listaCadUsuario');
        if (!lista) {
            console.error('Elemento listaCadUsuario não encontrado');
            return;
        }

        const response = await fetch('http://localhost:3000/usuarios');
        if (!response.ok) {
            throw new Error('Erro na resposta da API: ' + response.status);
        }
        const usuarios = await response.json();
        lista.innerHTML = ''; // Limpa a lista existente

        if (usuarios.length === 0) {
            lista.innerHTML = 'Nenhum usuário cadastrado.';
        } else {
            usuarios.forEach((usuario) => {
                const item = document.createElement('div');
                item.className = 'ItemUser';

                item.innerHTML = `
                    <div class="DadosUser">
                        <p class="NomeUser">${usuario.nome}</p>
                        <p class="Emailuser">${usuario.email}</p>
                        <p class="SenhaUser">
                            <span class="senhaOculta">${'*'.repeat(usuario.senha.length)}</span>
                            <span class="senhaVisivel" style="display:none;">${usuario.senha}</span>
                            <button class="btnMostrarSenha" onclick="toggleSenha(this)">Mostrar</button>
                        </p>
                        <p class="BirthUser">${new Date(usuario.dataAniversario).toLocaleDateString()}</p>
                    </div>
                    <div class="AreaModificacoes">
                        <button class="btnAlterar" onclick="carregarDados(${usuario.id})">Alterar</button>
                        <button class="btnDeletar" onclick="deletar(${usuario.id})">Deletar</button>
                    </div>
                `;

                lista.appendChild(item);
            });
        }

        // Verifica se o usuário em edição ainda existe
        if (usuarioEmEdicaoId !== null) {
            const usuarioExiste = usuarios.some(u => u.id === usuarioEmEdicaoId);
            if (!usuarioExiste) {
                limparFormulario();
            }
        }
    } catch (error) {
        console.error('Erro ao listar usuários:', error);
        alert('Erro ao carregar a lista de usuários. Por favor, tente novamente.');
    }
}

// Função para carregar dados do usuário para alteração
async function carregarDados(id) {
    try {
        const response = await fetch(`http://localhost:3000/usuarios/${id}`);
        if (!response.ok) {
            throw new Error('Erro ao carregar dados do usuário');
        }
        const usuario = await response.json();

        document.getElementById('edtNome').value = usuario.nome;
        document.getElementById('edtEmail').value = usuario.email;
        document.getElementById('edtSenha').value = usuario.senha;
        document.getElementById('edtBirth').value = usuario.dataAniversario.split('T')[0]; // Ajusta o formato da data

        // Mudar o botão de "Gravar" para "Alterar"
        const btnGravar = document.querySelector('input[type="button"][onclick="gravar()"]');
        btnGravar.value = 'Alterar';
        btnGravar.setAttribute('onclick', `alterar(${id})`);

        // Armazena o ID do usuário em edição
        usuarioEmEdicaoId = id;
    } catch (error) {
        console.error('Erro ao carregar dados do usuário:', error);
        alert('Erro ao carregar dados do usuário. Por favor, tente novamente.');
    }
}

// Função para alterar um usuário existente
async function alterar(id) {
    const nome = document.getElementById('edtNome').value;
    const email = document.getElementById('edtEmail').value;
    const senha = document.getElementById('edtSenha').value;
    const dataAniversario = document.getElementById('edtBirth').value;

    try {
        const response = await fetch(`http://localhost:3000/usuarios/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ nome, email, senha, dataAniversario }),
        });

        if (!response.ok) {
            throw new Error('Erro ao alterar usuário');
        }

        console.log('Usuário alterado com sucesso');

        // Limpar o formulário e restaurar o botão para "Gravar"
        limparFormulario();

        // Atualizar a lista de usuários
        listarUsuarios();
    } catch (error) {
        console.error('Erro ao alterar usuário:', error);
        alert('Erro ao alterar usuário. Por favor, tente novamente.');
    }
}

// Função para deletar um usuário
async function deletar(id) {
    if (!confirm('Tem certeza que deseja deletar este usuário?')) {
        return;
    }

    try {
        const response = await fetch(`http://localhost:3000/usuarios/${id}`, {
            method: 'DELETE',
        });

        if (!response.ok) {
            throw new Error('Erro ao deletar usuário');
        }

        console.log('Usuário deletado com sucesso');
        
        // Se o usuário deletado era o que estava sendo editado, limpa o formulário
        if (id === usuarioEmEdicaoId) {
            limparFormulario();
        }
        
        listarUsuarios(); // Atualizar a lista de usuários
    } catch (error) {
        console.error('Erro ao deletar usuário:', error);
        alert('Erro ao deletar usuário. Por favor, tente novamente.');
    }
}

// Função para pesquisar usuários
async function pesquisar() {
    const pesquisa = document.getElementById('edtPesquisar').value.toLowerCase();

    try {
        const response = await fetch('http://localhost:3000/usuarios');
        if (!response.ok) {
            throw new Error('Erro ao buscar usuários');
        }
        const usuarios = await response.json();

        const lista = document.getElementById('listaCadUsuario');
        lista.innerHTML = '';

        const resultado = usuarios.filter(usuario =>
            usuario.nome.toLowerCase().includes(pesquisa) ||
            usuario.email.toLowerCase().includes(pesquisa)
        );

        if (resultado.length === 0) {
            lista.innerHTML = 'Nenhum usuário encontrado.';
        } else {
            resultado.forEach((usuario) => {
                const item = document.createElement('div');
                item.className = 'ItemUser';

                item.innerHTML = `
                    <div class="DadosUser">
                        <p class="NomeUser">${usuario.nome}</p>
                        <p class="Emailuser">${usuario.email}</p>
                        <p class="SenhaUser">
                            <span class="senhaOculta">${'*'.repeat(usuario.senha.length)}</span>
                            <span class="senhaVisivel" style="display:none;">${usuario.senha}</span>
                            <button class="btnMostrarSenha" onclick="toggleSenha(this)">Mostrar</button>
                        </p>
                        <p class="BirthUser">${new Date(usuario.dataAniversario).toLocaleDateString()}</p>
                    </div>
                    <div class="AreaModificacoes">
                        <button class="btnAlterar" onclick="carregarDados(${usuario.id})">Alterar</button>
                        <button class="btnDeletar" onclick="deletar(${usuario.id})">Deletar</button>
                    </div>
                `;

                lista.appendChild(item);
            });
        }
    } catch (error) {
        console.error('Erro ao pesquisar usuários:', error);
        alert('Erro ao pesquisar usuários. Por favor, tente novamente.');
    }
}

// Função para limpar o formulário
function limparFormulario() {
    document.getElementById('edtNome').value = '';
    document.getElementById('edtEmail').value = '';
    document.getElementById('edtSenha').value = '';
    document.getElementById('edtBirth').value = '';

    // Restaurar o botão para "Gravar"
    const btnGravar = document.querySelector('input[type="button"][onclick^="alterar("]');
    if (btnGravar) {
        btnGravar.value = 'Gravar';
        btnGravar.setAttribute('onclick', 'gravar()');
    }

    // Resetar o ID do usuário em edição
    usuarioEmEdicaoId = null;
}

// Função para ordenar a lista por nome
function ordenarPorNome() {
    const lista = document.getElementById('listaCadUsuario');
    const itens = Array.from(lista.getElementsByClassName('ItemUser'));

    itens.sort((a, b) => {
        const nomeA = a.querySelector('.NomeUser').textContent.toLowerCase();
        const nomeB = b.querySelector('.NomeUser').textContent.toLowerCase();
        return nomeA.localeCompare(nomeB);
    });

    lista.innerHTML = '';
    itens.forEach(item => lista.appendChild(item));
}

// Função para esvaziar a lista
async function esvaziarLista() {
    if (!confirm('Tem certeza que deseja esvaziar toda a lista de usuários? Esta ação não pode ser desfeita.')) {
        return;
    }

    try {
        const response = await fetch('http://localhost:3000/usuarios', {
            method: 'DELETE'
        });

        if (!response.ok) {
            throw new Error('Erro ao esvaziar a lista de usuários');
        }

        console.log('Lista de usuários esvaziada com sucesso');
        limparFormulario();
        listarUsuarios(); // Atualiza a lista (que agora estará vazia)
    } catch (error) {
        console.error('Erro ao esvaziar a lista de usuários:', error);
        alert('Erro ao esvaziar a lista de usuários. Por favor, tente novamente.');
    }
}

// Função para alternar a visibilidade da senha
function toggleSenha(button) {
    const senhaOculta = button.previousElementSibling.previousElementSibling;
    const senhaVisivel = button.previousElementSibling;

    if (senhaOculta.style.display === 'none') {
        senhaOculta.style.display = 'inline';
        senhaVisivel.style.display = 'none';
        button.textContent = 'Mostrar';
    } else {
        senhaOculta.style.display = 'none';
        senhaVisivel.style.display = 'inline';
        button.textContent = 'Ocultar';
    }
}

// Event listener para carregar a lista de usuários quando a página carregar
document.addEventListener('DOMContentLoaded', listarUsuarios);

// Event listener para o campo de pesquisa
document.getElementById('edtPesquisar').addEventListener('input', pesquisar);

// Event listener para o botão de ordenar por nome
document.getElementById('btnOrdenarNome').addEventListener('click', ordenarPorNome);

// Event listener para o botão de esvaziar lista
document.getElementById('btnEsvaziarLista').addEventListener('click', esvaziarLista);